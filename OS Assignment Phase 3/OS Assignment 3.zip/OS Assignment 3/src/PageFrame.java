//Class of A Memory Page
public class PageFrame {
    Ubyte[] memory = new Ubyte[128];  //Decimal Memory Pages
    String[] hexmemory = new String[128];  //HexaDecimal Memory Page
}
