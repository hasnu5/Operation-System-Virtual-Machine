//Class of Computer Register
public class Register {
    String code; //A byte Sized Code in hexadecimal
    public short value; //A short sized value
}
